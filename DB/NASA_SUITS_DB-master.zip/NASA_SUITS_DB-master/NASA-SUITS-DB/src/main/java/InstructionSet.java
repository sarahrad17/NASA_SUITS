import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

import java.io.Serializable;

public class InstructionSet implements Serializable {

    private static final long serialVersionUID = 1L;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ArrayList<Instruction> getInstructions() {
        return instructions;
    }

    public void setInstructions(ArrayList<Instruction> instructions) {
        this.instructions = instructions;
    }

    private String name;
    private int id;
    private ArrayList<Instruction> instructions = new ArrayList<Instruction>();
    private String model_URL;

    public InstructionSet(String name, int id, ArrayList<Instruction> instructions, String model_url){
        this.name = name;
        this.id = id;
        this.instructions = instructions;
        this.model_URL = model_url;
    }



}
