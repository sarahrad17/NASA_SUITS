import java.util.ArrayList;

public class Instruction {

    public String text;
    public ArrayList<String> asset_urls;
    public int step;

    public Instruction(String text, ArrayList<String> asset_urls, int step) {
        this.text = text;
        this.asset_urls = asset_urls;
        this.step = step;
    }
}
