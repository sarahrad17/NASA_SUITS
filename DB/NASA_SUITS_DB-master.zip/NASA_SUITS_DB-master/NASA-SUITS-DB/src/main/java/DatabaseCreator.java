import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.*;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.bson.Document;


public class DatabaseCreator {


    public static void main(String[] args) {
        DatabaseCreator d = new DatabaseCreator();
    }

    public DatabaseCreator(){
        createDatabase();
    }


    public void createDatabase(){
        //CREATE MONGODB CONNECTION
        System.out.println("adding to MongoDB");
        MongoClientURI uri = new MongoClientURI(
                "mongodb+srv://admin:lmao@lunar-lion-3oams.mongodb.net/test?retryWrites=true&w=majority");

        MongoClient mongoClient = new MongoClient(uri);
        MongoDatabase db = mongoClient.getDatabase("NASA-Suits");
        MongoCollection collection = db.getCollection("Instructions");

        ArrayList<Instruction> instructions = new ArrayList<Instruction>();
        try {
            Reader in = new FileReader("ChangeTire.csv");
            Iterable<CSVRecord> records = CSVFormat.EXCEL.withFirstRecordAsHeader().parse(in);
            for (CSVRecord record : records) {
                Integer step = Integer.parseInt(record.get(0));
                String instruction = record.get(1);
                int i = 2;
                ArrayList<String> urlList = new ArrayList<String>();
                boolean hasVal = record.isSet(i);
                while(hasVal){
                    String asset_url = record.get(i);
                    if(asset_url.trim().length() >0) {
                        urlList.add(asset_url);
                    }
                    i++;
                    hasVal = record.isSet(i);
                }
                Instruction instruction1 = new Instruction(instruction, urlList, step);
                instructions.add(instruction1);
            }
        }
        catch(IOException e){
            e.printStackTrace();
        }

        String model_url = "rover_normal.blend";
        InstructionSet instructionSet=  new InstructionSet("Change Rover Tire", 001, instructions, model_url);
        Gson gson = new Gson();
        String json = gson.toJson(instructionSet);
        JsonObject jsonObject = new JsonParser().parse(json).getAsJsonObject();
        String id = jsonObject.get("id").getAsString();
        jsonObject.addProperty("_id", id);
        Document doc = Document.parse(jsonObject.toString());
        try {
            collection.insertOne(doc);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Avoided Duplicate");
        }


    }
}
